document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  const resultArea = document.getElementById('resultArea');
  const viewBtn = document.getElementById('viewBtn');

  // Auto focus input
  searchInput.focus();

  // Enter key support
  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      performSearch();
    }
  });

  searchBtn.addEventListener('click', performSearch);

  function performSearch() {
    const query = searchInput.value.trim();
    const queryLower = query.toLowerCase();
    
    if (!queryLower) {
      hideResults();
      return;
    }

    // Exact match
    const exactMatch = ITEMS.find(item => item.toLowerCase() === queryLower);
    
    if (exactMatch) {
      showExactMatch(exactMatch);
      return;
    }

    // Partial match
    const partialMatches = ITEMS.filter(item => item.toLowerCase().includes(queryLower));

    if (partialMatches.length > 0) {
      showPartialMatches(partialMatches, query);
    } else {
      showNoMatch(query);
    }
  }

  function hideResults() {
    resultArea.innerHTML = '';
    resultArea.classList.add('hidden');
    viewBtn.classList.add('hidden');
  }

  function showExactMatch(item) {
    resultArea.innerHTML = `
      <div class="match-exact">
        ✅ Available on SwigMenus
      </div>
    `;
    resultArea.classList.remove('hidden');
    
    setupViewButton(item);
  }

  function showPartialMatches(matches, originalQuery) {
    const topMatches = matches.slice(0, 5);
    
    const listHtml = topMatches.map(match => `<li>${escapeHtml(match)}</li>`).join('');
    
    resultArea.innerHTML = `
      <div class="match-partial-title">Possible matches:</div>
      <ul class="match-partial-list">
        ${listHtml}
      </ul>
    `;
    resultArea.classList.remove('hidden');
    
    setupViewButton(originalQuery);
  }

  function showNoMatch(query) {
    resultArea.innerHTML = `
      <div class="match-none">
        ❌ No matching item found
      </div>
    `;
    resultArea.classList.remove('hidden');
    
    setupViewButton(query);
  }

  function setupViewButton(query) {
    viewBtn.href = `https://swigmenus.com`;
    viewBtn.classList.remove('hidden');
  }

  function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
  }
});
